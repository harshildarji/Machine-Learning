op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  dg : __torch__.MyDecisionGate
  linear : __torch__.torch.nn.modules.module.___torch_mangle_3.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_4.Module,
    input: Tensor,
    h: Tensor) -> Tuple[Tensor, Tensor]:
    _0 = (self.dg).forward((self.linear).forward(input, ), )
    _1 = torch.tanh(torch.add(_0, h, alpha=1))
    return (_1, _1)
